# -*- coding: utf-8 -*-
# Service LegendasDivx.pt version 2.1.9
# Code based on Undertext (FRODO) service
# Coded by HiGhLaNdR@OLDSCHOOL
# Ported to Gotham by HiGhLaNdR@OLDSCHOOL
# Python 3 / Kodi 21 (Omega) Revision and Bugfixes
# Help by VaRaTRoN
# Bugs & Features to highlander@teknorage.com
# http://www.teknorage.com
# License: GPL v2

import os
from os.path import join as pjoin
import fnmatch
import shutil
import sys
import string
import time
import unicodedata
import urllib.request, urllib.parse, urllib.error
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import http.cookiejar
import uuid
import socket
import re

_addon = xbmcaddon.Addon()
_author     = _addon.getAddonInfo('author')
_scriptid   = _addon.getAddonInfo('id')
_scriptname = _addon.getAddonInfo('name')
_version    = _addon.getAddonInfo('version')
_dialog     = xbmcgui.Dialog()

_cwd        = xbmcvfs.translatePath(_addon.getAddonInfo('path'))
_profile    = xbmcvfs.translatePath(_addon.getAddonInfo('profile'))
_resource   = xbmcvfs.translatePath(os.path.join(_cwd, 'resources', 'lib' ))
_temp       = xbmcvfs.translatePath(os.path.join(_profile, 'temp'))

sys.path.append (_resource)

_descon = _addon.getSetting( 'DESC' )
_search = _addon.getSetting( 'SEARCH' )
debug = _addon.getSetting( 'DEBUG' )

main_url = "https://www.legendasdivx.pt/"
debug_pretext = "LegendasDivx"

INTERNAL_LINK_URL = "plugin://%(scriptid)s/?action=download&id=%(id)s&filename=%(filename)s"
SUB_EXTS = ['srt', 'sub', 'txt', 'ass', 'ssa', 'smi']
HTTP_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

#====================================================================================================================
# Regular expression patterns
#====================================================================================================================

subtitle_pattern = "<div\sclass=\"sub_box\">.+?<div\sclass=\"sub_header\">.+?<b>(.*?)</b>\s\((\d\d\d\d)\)\s.+?name=User_Info&username=(.+?)'><b>.+?</div>.+?<table\sclass=\"sub_main\scolor1\"\scellspacing=\"0\">.+?<tr>.+?<th>CDs:</th>.+?<td>(.+?)</td>.+?<a\shref=\"\?name=Downloads&d_op=ratedownload&lid=(.+?)\">.+?<th\sclass=\"color2\">Hits:</th>.+?<td>([^\s]+).+?<td>(.+?)</td>.+?<td\scolspan=\"5\"\sclass=\"td_desc\sbrd_up\">(.*?)</td>.+?<td\sclass"
release_pattern = "([^\W][\w\.]{1,}\w{1,}[\.]{1,1}[^\.|^\ |^\.org|^\.com|^\.net][^\Ws|^\.org|^\.com|^\.net][\w{1,}\.|\-|\(\d\d\d\d\)|\[\d\d\d\d\]]{3,}[^\Ws|^\.org|^\.com|^\.net][\w{3,}\-|\.{1,1}]\w{2,})"
release_pattern1 = "([^\W][\w\ |\]|[]{4,}[^\Ws][x264|xvid|ac3]{1,}-[\w\[\]]{1,})"
year_pattern = "(19|20)\d{2}$"

#==========
# Functions
#==========

def _log(module, msg):
    s = "### [%s] - %s" % (module, msg)
    xbmc.log(s, level=xbmc.LOGDEBUG)

def log(msg):
    if debug == 'true': _log(_scriptname, msg)

def recursive_glob(treeroot, extensions):
    extensions = set(extensions)
    results = []
    for base, dirs, files in os.walk(treeroot):
        for filename in files:
            _, ext = os.path.splitext(filename)
            if ext.lower()[1:] in extensions:
                results.append(os.path.join(base, filename).replace('\\', '/'))
    return results

def login():
    username = _addon.getSetting( 'LDuser' )
    password = _addon.getSetting( 'LDpass' )
    login_postdata = urllib.parse.urlencode({'username' : username, 'password' : password, 'login' : 'Login', 'sid' : ''}).encode("utf-8")
    cj = http.cookiejar.CookieJar()
    my_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    urllib.request.install_opener(my_opener)
    headers = {'User-Agent': HTTP_USER_AGENT}
    request = urllib.request.Request(main_url + 'forum/ucp.php?mode=login', data=login_postdata, headers=headers)
    urllib.request.urlopen(request, None, 6.5).read().decode('ISO-8859-1')    
    return my_opener

def urlpost(query, lang, page):
    my_opener = login()
    postdata = urllib.parse.urlencode({'query': query, 'form_cat': lang}).encode("utf-8")
    headers = {
        'Referer': main_url + 'modules.php?name=Downloads&file=jz&d_op=search&op=_jz00&page=' + str(page),
        'User-Agent': HTTP_USER_AGENT
    }
    request = urllib.request.Request(main_url + 'modules.php?name=Downloads&file=jz&d_op=search&op=_jz00&page=' + str(page), data=postdata, headers=headers)
    log("POST url page 1: %s" % query)
    try:
        response = my_opener.open(request, timeout=6.5).read().decode('ISO-8859-1')
        response = re.sub(r'<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>', '', response, flags=re.IGNORECASE)
        response = response.replace('document.currentScript.previousElementSibling.querySelector', '')
        return response
    except Exception as e:
        log("urlpost error: %s" % str(e))
        return ''

def urlget(query, lang, page):
    my_opener = login()
    query_safe = urllib.parse.quote_plus(query)
    url = main_url + f"modules.php?name=Downloads&file=jz&d_op=search_next&order=&form_cat={lang}&page={page}&query={query_safe}"
    headers = {
        'Referer': main_url + 'modules.php?name=Downloads',
        'User-Agent': HTTP_USER_AGENT
    }
    request = urllib.request.Request(url, headers=headers)
    log("GET url page %s: %s" % (page, url))
    try:
        response = my_opener.open(request, timeout=6.5).read().decode('ISO-8859-1')
        response = re.sub(r'<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>', '', response, flags=re.IGNORECASE)
        response = response.replace('document.currentScript.previousElementSibling.querySelector', '')
        return response
    except Exception as e:
        log("urlget error: %s" % str(e))
        return ''

def get_clean_title(title_string):
    if not title_string:
        return "", ""
    name = os.path.splitext(title_string)[0]
    match = re.search(r'^(.*?)(?:[ \.\-\_]+)(19\d{2}|20\d{2})(?:[ \.\-\_]+|$)', name)
    if match:
        c_title = match.group(1).replace('.', ' ').replace('_', ' ').strip()
        c_year = match.group(2)
        return c_title, c_year
    return name.replace('.', ' ').replace('_', ' ').strip(), ""

def getallsubs(searchstring, languageshort, languagelong, file_original_path, searchstring_notclean):
    subtitles_list = []
    log("getallsubs: Search String = '%s'" % searchstring)
    
    lang_codes = {"pt": "28", "pb": "29", "es": "30", "en": "31"}
    lang_code = lang_codes.get(languageshort, "28")
    
    page = 1
    while page <= 5:
        if page == 1:
            content = urlpost(searchstring, lang_code, page)
        else:
            content = urlget(searchstring, lang_code, page)
            
        matches_found = False
        if re.search(subtitle_pattern, content, re.IGNORECASE | re.DOTALL | re.MULTILINE):
            for matches in re.finditer(subtitle_pattern, content, re.IGNORECASE | re.DOTALL | re.X):
                matches_found = True
                uploader = matches.group(3)
                hits = matches.group(6)
                id = str.split(matches.group(5), '"')[0]
                movieyear = matches.group(2)
                no_files = matches.group(4)
                downloads = int(matches.group(6)) / 200
                if (downloads > 5): downloads = 5
                
                raw_filename = matches.group(1)
                clean_filename = re.sub(r'<script[^>]*>.*?</script>', '', raw_filename, flags=re.IGNORECASE|re.DOTALL)
                clean_filename = re.sub(r'<[^>]+>', '', clean_filename)
                clean_filename = re.sub(r'document\.currentScript.*?;', '', clean_filename)
                clean_filename = clean_filename.replace('document.currentScript.previousElementSibling.querySelector', '')
                filename = str.strip(clean_filename)
                filename = re.sub('\n',' ',filename)

                desc_ori = str.strip(matches.group(8))
                desc_ori = re.sub(r'www\.legendasdivx\.(com|pt)','',desc_ori)
                
                _filenameon = "true"
                if _descon == "false":
                    desc = re.findall(release_pattern, desc_ori, re.IGNORECASE | re.VERBOSE | re.DOTALL | re.UNICODE | re.MULTILINE)
                    desc = " / ".join(desc)
                    if desc != "": _filenameon = "false"
                    if desc == "":
                        desc = re.findall(release_pattern1, desc_ori, re.IGNORECASE | re.VERBOSE | re.DOTALL | re.UNICODE | re.MULTILINE)
                        desc = " / ".join(desc)
                        if desc != "": _filenameon = "false"
                        if desc == "": desc = desc_ori; _filenameon = "true"
                        else: desc = desc; _filenameon = "false"
                else: desc = desc_ori; _filenameon = "true"
                
                desc = re.sub('<br />',' ',desc)
                desc = re.sub('<br>',' ',desc)
                desc = re.sub('\n',' ',desc)
                desc = re.sub(':.','',desc)
                desc = re.sub(r'<[^<]+?>|[~]','', desc)

                global filesearch
                filesearch = os.path.abspath(file_original_path)
                filesearch = os.path.split(filesearch)
                dirsearch = filesearch[0].split(os.sep)
                dirsearch_check = str.split(dirsearch[-1], '.')

                _parentfolder = _addon.getSetting( 'PARENT' )
                if _parentfolder == '0':
                    if re.search(release_pattern, dirsearch[-1], re.IGNORECASE): _parentfolder = '1'
                    else: _parentfolder = '2'
                if _parentfolder == '1':
                    if re.search(dirsearch[-1], desc, re.IGNORECASE): sync = True
                    else: sync = False
                if _parentfolder == '2':
                    if (searchstring_notclean != ""):
                        sync = False
                        if str.lower(searchstring_notclean) in str.lower(desc): sync = True
                    else:
                        if (str.lower(dirsearch_check[-1]) == "rar") or (str.lower(dirsearch_check[-1]) == "cd1") or (str.lower(dirsearch_check[-1]) == "cd2"):
                            sync = False
                            if len(dirsearch) > 1 and dirsearch[1] != '':
                                if re.search(filesearch[1][:len(filesearch[1])-4], desc, re.IGNORECASE) or re.search(dirsearch[-2], desc, re.IGNORECASE): sync = True
                            else:
                                if re.search(filesearch[1][:len(filesearch[1])-4], desc, re.IGNORECASE): sync = True
                        else:
                            sync = False
                            if len(dirsearch) > 1 and dirsearch[1] != '':
                                if re.search(filesearch[1][:len(filesearch[1])-4], desc) or re.search(dirsearch[-1], desc, re.IGNORECASE): sync = True
                            else:
                                if re.search(filesearch[1][:len(filesearch[1])-4], desc, re.IGNORECASE): sync = True
                                
                if _filenameon == "false": filename = "From: " + uploader + " - "  + desc + "  " + "hits: " + hits
                else: filename = "From: " + uploader + " - "  + filename + " " + "(" + movieyear + ")" + "  " + "hits: " + hits + " - " + desc
                
                subtitles_list.append({'rating': str(downloads), 'filename': filename, 'uploader': uploader, 'desc': desc, 'sync': sync, 'hits' : hits, 'id': id, 'language_short': languageshort, 'language_name': languagelong})

        if not matches_found:
            break
            
        page += 1
        xbmc.sleep(200)

    for n in range(0,len(subtitles_list)):
        for i in range(1, len(subtitles_list)):
            temp = subtitles_list[i]
            if subtitles_list[i]["sync"] > subtitles_list[i-1]["sync"]:
                subtitles_list[i] = subtitles_list[i-1]
                subtitles_list[i-1] = temp
                
    return subtitles_list

def append_subtitle(item):
    listitem = xbmcgui.ListItem(label=item['language_name'], label2=item['filename'])
    listitem.setArt({ "icon": str(int(round(float(item["rating"])))), "thumb" : item["language_short"] })
    listitem.setProperty("sync", 'true' if item["sync"] else 'false')
    listitem.setProperty("hearing_imp", 'true' if item.get("hearing_imp", False) else 'false')

    args = dict(item)
    args['scriptid'] = _scriptid
    url = INTERNAL_LINK_URL % args
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=False)

class Main:
    def Search(item):
        username = _addon.getSetting( 'LDuser' )
        password = _addon.getSetting( 'LDpass' )
        if not username or not password:
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            if username == '' and password != '': _dialog.notification(_scriptname, _addon.getLocalizedString(32016), xbmcgui.NOTIFICATION_ERROR)
            if username != '' and password == '': _dialog.notification(_scriptname, _addon.getLocalizedString(32017), xbmcgui.NOTIFICATION_ERROR)
            if username == '' and password == '': _dialog.notification(_scriptname, _addon.getLocalizedString(32018), xbmcgui.NOTIFICATION_ERROR)
            
        file_original_path = item['file_original_path']
        _parentfolder = _addon.getSetting( 'PARENT' )
        if _parentfolder == '0':
            filename_path = os.path.abspath(file_original_path)
            dirsearch = filename_path.split(os.sep)
            if re.search(release_pattern, dirsearch[-2], re.IGNORECASE): _parentfolder = '1'
            else: _parentfolder = '2'
        if _parentfolder == '1':
            filename_path = os.path.abspath(file_original_path)
            dirsearch = filename_path.split(os.sep)
            filename = dirsearch[-2]
        if _parentfolder == '2':   
            filename = os.path.splitext(os.path.basename(file_original_path))[0]
     
        c_title, c_year = get_clean_title(filename)
        filename = f"{c_title} {c_year}".strip()
        
        searchstring_notclean = os.path.splitext(os.path.basename(file_original_path))[0]
        searchstring = ""
        global israr
        israr = os.path.abspath(file_original_path)
        israr = os.path.split(israr)
        israr = israr[0].split(os.sep)
        israr = str.split(israr[-1], '.')
        israr = str.lower(israr[-1])

        title, _ = get_clean_title(item['title']) if item['title'] else ("", "")
        year = item['year']
        
        tvshow = item['tvshow']
        if tvshow:
            tvshow = tvshow.split('(')[0].strip()
        season = item['season']
        episode = item['episode']
        
        if item['mansearch']:
            searchstring = item['mansearchstr']
        else:
            if episode != '' and episode is not None and str(episode).isdigit():
                show_name = tvshow if tvshow else title
                if not show_name:
                    show_name, _ = get_clean_title(filename)
                searchstring = "%s S%02dE%02d" % (show_name, int(season), int(episode))
            elif title != '' and (episode == '' or episode is None or not str(episode).isdigit()):
                searchstring = "%s %s" % (title, year)
            else:
                if 'rar' in israr and searchstring is not None:
                    if 'cd1' in str.lower(title) or 'cd2' in str.lower(title) or 'cd3' in str.lower(title):
                        dirsearch = os.path.abspath(file_original_path)
                        dirsearch = os.path.split(dirsearch)
                        dirsearch = dirsearch[0].split(os.sep)
                        if len(dirsearch) > 1:
                            searchstring_notclean = dirsearch[-3]
                            c_tit, _ = get_clean_title(dirsearch[-3])
                            searchstring = c_tit
                        else: searchstring = title
                    else:
                        searchstring = filename
                elif 'cd1' in str.lower(title) or 'cd2' in str.lower(title) or 'cd3' in str.lower(title):
                    dirsearch = os.path.abspath(file_original_path)
                    dirsearch = os.path.split(dirsearch)
                    dirsearch = dirsearch[0].split(os.sep)
                    if len(dirsearch) > 1:
                        searchstring_notclean = dirsearch[-2]
                        c_tit, _ = get_clean_title(dirsearch[-2])
                        searchstring = c_tit
                    else:
                        title = os.path.split(file_original_path)
                        searchstring = title[-1]
                else:
                    if _search == '0':
                        if re.search("(.+?s[0-9][0-9]e[0-9][0-9])", filename, re.IGNORECASE):
                            match = re.search("(.+?s[0-9][0-9]e[0-9][0-9])", filename, re.IGNORECASE)
                            searchstring = match.group(0)
                        else:
                            searchstring = filename
                    else:
                        if re.search("(.+?s[0-9][0-9]e[0-9][0-9])", title, re.IGNORECASE):
                            match = re.search("(.+?s[0-9][0-9]e[0-9][0-9])", title, re.IGNORECASE)
                            searchstring = match.group(0)
                        else:
                            searchstring = title

        searchstring = searchstring.strip()

        # Limpeza normalizada de texto
        searchstring_for_web = re.sub(r'[\.\-\_]+', ' ', searchstring)
        searchstring_for_web = re.sub(r'(?i)\b[sS]\d{1,2}[eE]\d{1,2}\b.*', '', searchstring_for_web)
        searchstring_for_web = re.sub(r'(?i)\b\d{1,2}x\d{1,2}\b.*', '', searchstring_for_web)
        searchstring_for_web = re.sub(r'(?i)\bthe\b', '', searchstring_for_web)
        searchstring_for_web = re.sub(r'\s+', ' ', searchstring_for_web).strip()
        
        if not searchstring_for_web:
            searchstring_for_web = searchstring
            
        # NOVA LÓGICA: Injeção do IMDb ID 
        imdb_id = item.get('imdb', '')
        use_imdb_setting = _addon.getSetting('USE_IMDB')
        
        # --- BLOCO DE DEBUG (Regista no kodi.log) ---
        xbmc.log("### [LegendasDivx] DEBUG - Serie/Filme Original: '%s'" % item['title'], level=xbmc.LOGINFO)
        xbmc.log("### [LegendasDivx] DEBUG - Temporada: '%s' | Episodio: '%s'" % (season, episode), level=xbmc.LOGINFO)
        xbmc.log("### [LegendasDivx] DEBUG - IMDb ID fornecido pelo Kodi: '%s'" % imdb_id, level=xbmc.LOGINFO)
        xbmc.log("### [LegendasDivx] DEBUG - Pesquisa Manual Ativada: '%s'" % item['mansearch'], level=xbmc.LOGINFO)
        # --------------------------------------------

        # Agora, se for pesquisa manual (mansearch == True), o add-on salta o IMDb e usa o teu texto!
        if use_imdb_setting == 'true' and imdb_id.startswith('tt') and not item['mansearch']:
            searchstring_for_web = imdb_id
            xbmc.log("### [LegendasDivx] DEBUG - A enviar para o site o ID -> %s" % searchstring_for_web, level=xbmc.LOGINFO)
        else:
            xbmc.log("### [LegendasDivx] DEBUG - A enviar para o site o texto -> %s" % searchstring_for_web, level=xbmc.LOGINFO)

        PT_ON = _addon.getSetting( 'PT' )
        PTBR_ON = _addon.getSetting( 'PTBR' )
        ES_ON = _addon.getSetting( 'ES' )
        EN_ON = _addon.getSetting( 'EN' )
        
        master_subs = []
        
        if 'por' in item['languages'] and PT_ON == 'true':
            master_subs.extend(getallsubs(searchstring_for_web, "pt", "Portuguese", file_original_path, searchstring_notclean))
        if 'por' in item['languages'] and PTBR_ON == 'true':
            master_subs.extend(getallsubs(searchstring_for_web, "pb", "Brazilian", file_original_path, searchstring_notclean))
        if 'spa' in item['languages'] and ES_ON == 'true':
            master_subs.extend(getallsubs(searchstring_for_web, "es", "Spanish", file_original_path, searchstring_notclean))
        if 'eng' in item['languages'] and EN_ON == 'true':
            master_subs.extend(getallsubs(searchstring_for_web, "en", "English", file_original_path, searchstring_notclean))
            
        if not master_subs and 'eng' not in item['languages'] and 'spa' not in item['languages'] and 'por' not in item['languages']:
            _dialog.notification(_scriptname, 'Only Portuguese | Portuguese Brazilian | English | Spanish.', xbmcgui.NOTIFICATION_ERROR)
            
        # Filtragem Local de Séries (Agora com suporte para E01, Ep1 em minisséries)
        if episode != '' and episode is not None and str(episode).isdigit():
            filtered_subs = []
            s_int = int(season)
            e_int = int(episode)

            regex_str = r'(s%02de%02d|s%de%d|%dx%02d|%02dx%02d|\be%02d\b|\be%d\b|\bep%02d\b)' % (s_int, e_int, s_int, e_int, s_int, e_int, s_int, e_int, e_int, e_int, e_int)
            regex_pack = r'(\bs0?%d\b|\bseason\s*0?%d\b|\btemporada\s*0?%d\b|\b[eé]poca\s*0?%d\b)' % (s_int, s_int, s_int, s_int)
            pattern = re.compile(f'({regex_str}|{regex_pack})', re.IGNORECASE)

            # --- DEBUG DA FILTRAGEM ---
            xbmc.log("### [LegendasDivx] DEBUG - Total de legendas sacadas do site (antes do filtro): %d" % len(master_subs), level=xbmc.LOGINFO)

            for sub in master_subs:
                match_found = pattern.search(sub['filename']) or pattern.search(sub['desc'])

                # Regista literalmente o nome da legenda e se passou ou chumbou no filtro
                if match_found:
                    xbmc.log("### [LegendasDivx] DEBUG - APROVADA: '%s'" % sub['filename'], level=xbmc.LOGINFO)
                    filtered_subs.append(sub)
                else:
                    xbmc.log("### [LegendasDivx] DEBUG - BLOQUEADA: '%s'" % sub['filename'], level=xbmc.LOGINFO)

            master_subs = filtered_subs
            xbmc.log("### [LegendasDivx] DEBUG - Total de legendas que sobreviveram ao filtro: %d" % len(master_subs), level=xbmc.LOGINFO)
            # --------------------------

        for sub in master_subs:
            append_subtitle(sub)
            
        for sub in master_subs:
            append_subtitle(sub)
            
    def Download(id, filename):
        if os.path.isdir(_temp):
            try: shutil.rmtree(_temp)
            except: pass
        os.makedirs(_temp, exist_ok=True)
        
        unpacked_dir = 'ldivx-' + str(uuid.uuid4()).replace("-","")[0:6]
        _newtemp = pjoin(_temp, unpacked_dir).replace('\\', '/')
        os.makedirs(_newtemp, exist_ok=True)

        subtitles_list = []
        my_opener = login()
        
        download_url = main_url + 'modules.php?name=Downloads&d_op=getit&lid=' + id + '&username=' + urllib.parse.quote(_addon.getSetting('LDuser'))
        
        try:
            response = my_opener.open(download_url, timeout=10)
            content = response.read()
        except Exception as e:
            log("Download failed: %s" % str(e))
            content = b''
        
        if b'url=sair.php?referer=login' in content:
            try: msg = _addon.getLocalizedString(32019)
            except: msg = "Erro de Login"
            _dialog.notification(_scriptname, msg, xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            return subtitles_list
            
        if len(content) > 0:
            header = content[:4].decode('ISO-8859-1', errors='ignore')
            packed = False
            
            if header.startswith('Rar!'):
                archive_filename = str(uuid.uuid4())+".rar"
                local_tmp_file = pjoin(_temp, archive_filename).replace('\\', '/')
                packed = True
            elif header.startswith('PK'):
                archive_filename = str(uuid.uuid4())+".zip"
                local_tmp_file = pjoin(_temp, archive_filename).replace('\\', '/')
                packed = True
            else:
                local_tmp_file = pjoin(_temp, "ldivx.srt").replace('\\', '/')
                subs_file = local_tmp_file
                
            try:
                with open(local_tmp_file, 'wb') as f:
                    f.write(content)
                xbmc.sleep(200)
            except Exception as e:
                log("Failed to save subtitles to '%s': %s" % (local_tmp_file, str(e)))
                
            if packed:
                extracted = False
                if header.startswith('PK'):
                    try:
                        import zipfile
                        with zipfile.ZipFile(local_tmp_file, 'r') as zip_ref:
                            zip_ref.extractall(_newtemp)
                        extracted = True
                        log("Extracted ZIP using Python native zipfile.")
                    except Exception as e:
                        log("Python zipfile extraction failed: %s" % str(e))
                        
                elif header.startswith('Rar!'):
                    try:
                        safe_path = urllib.parse.quote(local_tmp_file, safe='')
                        rar_vfs_path = f"rar://{safe_path}/"
                        dirs, files = xbmcvfs.listdir(rar_vfs_path)
                        for f in files:
                            if f.lower().endswith(tuple(SUB_EXTS)):
                                xbmcvfs.copy(f"{rar_vfs_path}{f}", pjoin(_newtemp, f).replace('\\', '/'))
                                extracted = True
                        for d in dirs:
                            sub_vfs_path = f"{rar_vfs_path}{d}/"
                            subdirs, subfiles = xbmcvfs.listdir(sub_vfs_path)
                            for sub_f in subfiles:
                                if sub_f.lower().endswith(tuple(SUB_EXTS)):
                                    xbmcvfs.copy(f"{sub_vfs_path}{sub_f}", pjoin(_newtemp, sub_f).replace('\\', '/'))
                                    extracted = True
                        if extracted:
                            log("Extracted RAR using VFS rar:// protocol.")
                    except Exception as e:
                        log("VFS rar extraction failed: %s" % str(e))
                
                if not extracted:
                    try:
                        log("Using XBMC.Extract builtin with special paths...")
                        special_archive = f"special://profile/addon_data/{_scriptid}/temp/{archive_filename}"
                        special_dest = f"special://profile/addon_data/{_scriptid}/temp/{unpacked_dir}/"
                        xbmc.executebuiltin(f'Extract("{special_archive}", "{special_dest}")')
                    except Exception as e:
                        log("XBMC.Extract error: %s" % str(e))
                        
                searchsubs = []
                for _ in range(40): 
                    searchsubs = recursive_glob(_newtemp, SUB_EXTS)
                    if searchsubs:
                        xbmc.sleep(300) 
                        searchsubs = recursive_glob(_newtemp, SUB_EXTS)
                        break
                    xbmc.sleep(250)
                    
                try: os.remove(local_tmp_file)
                except: pass
                
                if not searchsubs:
                    log("No subtitles found in archive.")
                    if header.startswith('Rar!'):
                        _dialog.notification("Aviso RAR", "Falha! Tem o add-on vfs.rar ativo?", xbmcgui.NOTIFICATION_WARNING, 5000)
                elif len(searchsubs) == 1:
                    subtitles_list.append(searchsubs[0])
                else:
                    xbmc.sleep(500)
                    dialog = xbmcgui.Dialog()
                    filenames = [os.path.basename(f) for f in searchsubs]
                    
                    try: title_str = _addon.getLocalizedString(32024)
                    except: title_str = "Escolher Legenda"
                    if not title_str: title_str = "Escolher Legenda"
                    
                    sel = dialog.select(title_str, filenames)
                    if sel >= 0:
                        subtitles_list.append(searchsubs[sel])
            else:
                subtitles_list.append(subs_file)
                
        return subtitles_list

    def get_params():
        param = []
        paramstring = sys.argv[2]
        if len(paramstring) >= 2:
            params = paramstring
            cleanedparams = params.replace('?', '')
            if params.endswith('/'): params = params[:-2] 
            pairsofparams = cleanedparams.split('&')
            param = {}
            for pair in pairsofparams:
                splitparams = {}
                splitparams = pair.split('=')
                if len(splitparams) == 2: param[splitparams[0]] = splitparams[1]
        return param

    params = get_params()

    if params['action'] == 'search' or params['action'] == 'manualsearch':
        item = {}
        item['temp']               = False
        item['rar']                = False
        item['year']               = xbmc.getInfoLabel("VideoPlayer.Year")
        item['season']             = str(xbmc.getInfoLabel("VideoPlayer.Season"))
        item['episode']            = str(xbmc.getInfoLabel("VideoPlayer.Episode"))
        item['tvshow']             = str(xbmc.getInfoLabel("VideoPlayer.TVshowtitle"))
        item['title']              = str(xbmc.getInfoLabel("VideoPlayer.OriginalTitle"))
        item['file_original_path'] = urllib.parse.unquote(xbmc.Player().getPlayingFile())
        
        # Tentativa de obter o IMDb ID através das Labels do Player do Kodi
        item['imdb'] = xbmc.getInfoLabel("VideoPlayer.IMDBNumber")
        if not item['imdb']:
            item['imdb'] = xbmc.getInfoLabel("VideoPlayer.UniqueID(imdb)")
            
        item['mansearch'] = False
        item['languages'] = []

        if 'searchstring' in params:
            item['mansearch'] = True
            item['mansearchstr'] = urllib.parse.unquote(params['searchstring'])

        for lang in urllib.parse.unquote(params['languages']).split(','):
            item['languages'].append(xbmc.convertLanguage(lang, xbmc.ISO_639_2))

        if "s" in item['episode'].lower():
            item['season'] = "0"
            item['episode'] = item['episode'][-1:]

        if "http" in item['file_original_path']: item['temp'] = True
        elif "rar://" in item['file_original_path']:
            item['rar'] = True
            item['file_original_path'] = os.path.dirname(item['file_original_path'][6:])
        elif "stack://" in item['file_original_path']:
            stackPath = item['file_original_path'].split(" , ")
            item['file_original_path'] = stackPath[0][8:]

        Search(item)

    elif params['action'] == 'download':
        subs = Download(params["id"], params["filename"])
        for sub in subs:
            listitem = xbmcgui.ListItem(label=sub)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sub, listitem=listitem, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))