# -*- coding: utf-8 -*-
# Service LegendasDivx.com version 2.0.3
# Code based on Undertext (FRODO) service
# Coded by HiGhLaNdR@OLDSCHOOL
# Ported to Gotham by HiGhLaNdR@OLDSCHOOL
# Python 3 / Kodi 21 (Omega) Revision and Bugfixes
# Help by VaRaTRoN
# Bugs & Features to highlander@teknorage.com
# http://www.teknorage.com
# License: GPL v2

import os
from os.path import join as pjoin
import fnmatch
import shutil
import sys
import string
import time
import unicodedata
import urllib.request, urllib.parse, urllib.error
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import http.cookiejar
import uuid
import socket
import re

_addon = xbmcaddon.Addon()
_author     = _addon.getAddonInfo('author')
_scriptid   = _addon.getAddonInfo('id')
_scriptname = _addon.getAddonInfo('name')
_version    = _addon.getAddonInfo('version')
_language   = _addon.getLocalizedString
_dialog     = xbmcgui.Dialog()

_cwd        = xbmcvfs.translatePath(_addon.getAddonInfo('path'))
_profile    = xbmcvfs.translatePath(_addon.getAddonInfo('profile'))
_resource   = xbmcvfs.translatePath(os.path.join(_cwd, 'resources', 'lib' ))
_temp       = xbmcvfs.translatePath(os.path.join(_profile, 'temp'))

if os.path.isdir(_temp):shutil.rmtree(_temp)
xbmcvfs.mkdirs(_temp)
if not os.path.isdir(_temp):xbmcvfs.mkdir(_temp)

sys.path.append (_resource)

_descon = _addon.getSetting( 'DESC' )
_search = _addon.getSetting( 'SEARCH' )
debug = _addon.getSetting( 'DEBUG' )

main_url = "https://www.legendasdivx.pt/"
debug_pretext = "LegendasDivx"

INTERNAL_LINK_URL = "plugin://%(scriptid)s/?action=download&id=%(id)s&filename=%(filename)s"
SUB_EXTS = ['srt', 'sub', 'txt', 'ass', 'ssa', 'smi']
HTTP_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

#====================================================================================================================
# Regular expression patterns
#====================================================================================================================

subtitle_pattern = "<div\sclass=\"sub_box\">.+?<div\sclass=\"sub_header\">.+?<b>(.*?)</b>\s\((\d\d\d\d)\)\s.+?name=User_Info&username=(.+?)'><b>.+?</div>.+?<table\sclass=\"sub_main\scolor1\"\scellspacing=\"0\">.+?<tr>.+?<th>CDs:</th>.+?<td>(.+?)</td>.+?<a\shref=\"\?name=Downloads&d_op=ratedownload&lid=(.+?)\">.+?<th\sclass=\"color2\">Hits:</th>.+?<td>([^\s]+).+?<td>(.+?)</td>.+?<td\scolspan=\"5\"\sclass=\"td_desc\sbrd_up\">(.*?)</td>.+?<td\sclass"
release_pattern = "([^\W][\w\.]{1,}\w{1,}[\.]{1,1}[^\.|^\ |^\.org|^\.com|^\.net][^\Ws|^\.org|^\.com|^\.net][\w{1,}\.|\-|\(\d\d\d\d\)|\[\d\d\d\d\]]{3,}[^\Ws|^\.org|^\.com|^\.net][\w{3,}\-|\.{1,1}]\w{2,})"
release_pattern1 = "([^\W][\w\ |\]|[]{4,}[^\Ws][x264|xvid|ac3]{1,}-[\w\[\]]{1,})"
year_pattern = "(19|20)\d{2}$"

#==========
# Functions
#==========

def _log(module, msg):
    s = "### [%s] - %s" % (module, msg)
    xbmc.log(s, level=xbmc.LOGDEBUG)

def log(msg):
    if debug == 'true': _log(_scriptname, msg)

def recursive_glob(treeroot, extensions):
    extensions = set(extensions)
    results = []
    for base, dirs, files in os.walk(treeroot):
        for filename in files:
            _, ext = os.path.splitext(filename)
            if ext.lower()[1:] in extensions:
                results.append(os.path.join(base, filename))
    return results

def xbmc_extract(SRC, DEST):
    dd_ext, ff_ext = xbmcvfs.listdir(SRC)
    ff_ext = (ff for ff in ff_ext if os.path.splitext(ff)[1][1:].lower() in SUB_EXTS)
    dest_path = xbmcvfs.translatePath(DEST)
    for ff in ff_ext:
        src_file = os.path.join(SRC, ff)
        dst_file = os.path.join(dest_path, ff)
        success = xbmcvfs.copy(src_file,dst_file)
        if not success:
            log("Error extracting: '%s' to '%s'" % (src_file,dst_file))
        else:
            log("Extracting: '%s' to '%s'" % (src_file,dst_file))
    for dd in dd_ext:
        dd_mk = os.path.join(DEST, dd)
        os.makedirs(dd_mk, exist_ok=True)
        now_SRC = os.path.join(SRC, dd, '')
        now_DEST = os.path.join(DEST, dd)
        success_dd = xbmc_extract(now_SRC, now_DEST)
        if not success_dd:
            log("Error extracting inside dir: '%s' to '%s'" % (now_SRC,now_DEST))

def login():
    username = _addon.getSetting( 'LDuser' )
    password = _addon.getSetting( 'LDpass' )
    login_postdata = urllib.parse.urlencode({'username' : username, 'password' : password, 'login' : 'Login', 'sid' : ''}).encode("utf-8")
    cj = http.cookiejar.CookieJar()
    my_opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cj))
    urllib.request.install_opener(my_opener)
    headers = {'User-Agent': HTTP_USER_AGENT}
    request = urllib.request.Request(main_url + 'forum/ucp.php?mode=login', data=login_postdata, headers=headers)
    response = urllib.request.urlopen(request, None, 6.5).read().decode('ISO-8859-1')    
    return my_opener

def urlpost(query, lang, page):
    my_opener = login()
    postdata = urllib.parse.urlencode({'query': query, 'form_cat': lang}).encode("utf-8")
    headers = {
        'Referer': main_url + 'modules.php?name=Downloads&file=jz&d_op=search&op=_jz00&page=' + str(page),
        'User-Agent': HTTP_USER_AGENT
    }
    request = urllib.request.Request(main_url + 'modules.php?name=Downloads&file=jz&d_op=search&op=_jz00&page=' + str(page), data=postdata, headers=headers)
    log("POST url page: %s" % page)
    log("POST url data: %s" % postdata)
    try:
        response = urllib.request.urlopen(request, None, 6.5).read().decode('ISO-8859-1')
        response = re.sub(r'<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>', '', response, flags=re.IGNORECASE)
        response = response.replace('document.currentScript.previousElementSibling.querySelector', '')
    except urllib.error.URLError as e:
        response = ''
        _dialog.notification(_scriptname, _language(32025).encode('utf8'), xbmcgui.NOTIFICATION_ERROR)
        log("Oops, site down?")
    except socket.timeout:
        response = ''
        _dialog.notification(_scriptname, _language(32026).encode('utf8'), xbmcgui.NOTIFICATION_ERROR)
        log("Timed out!")
    return response

def get_clean_title(title_string):
    if not title_string:
        return "", ""
    name = os.path.splitext(title_string)[0]
    match = re.search(r'^(.*?)(?:[ \.\-\_]+)(19\d{2}|20\d{2})(?:[ \.\-\_]+|$)', name)
    if match:
        c_title = match.group(1).replace('.', ' ').replace('_', ' ').strip()
        c_year = match.group(2)
        return c_title, c_year
    return name.replace('.', ' ').replace('_', ' ').strip(), ""

def getallsubs(searchstring, languageshort, languagelong, file_original_path, searchstring_notclean):
    subtitles_list = []
    log("getallsubs: Search String = '%s'" % searchstring)
    
    page = 1
    if languageshort == "pt": content = urlpost(searchstring, "28", page)
    elif languageshort == "pb": content = urlpost(searchstring, "29", page)
    elif languageshort == "es": content = urlpost(searchstring, "30", page)
    elif languageshort == "en": content = urlpost(searchstring, "31", page)
    
    if re.search(subtitle_pattern, content, re.IGNORECASE | re.DOTALL | re.MULTILINE):
        for matches in re.finditer(subtitle_pattern, content, re.IGNORECASE | re.DOTALL | re.X):
            uploader = matches.group(3)
            hits = matches.group(6)
            id = str.split(matches.group(5), '"')[0]
            movieyear = matches.group(2)
            no_files = matches.group(4)
            downloads = int(matches.group(6)) / 200
            if (downloads > 5): downloads = 5
            
            raw_filename = matches.group(1)
            clean_filename = re.sub(r'<script[^>]*>.*?</script>', '', raw_filename, flags=re.IGNORECASE|re.DOTALL)
            clean_filename = re.sub(r'<[^>]+>', '', clean_filename)
            clean_filename = re.sub(r'document\.currentScript.*?;', '', clean_filename)
            clean_filename = clean_filename.replace('document.currentScript.previousElementSibling.querySelector', '')
            filename = str.strip(clean_filename)
            filename = re.sub('\n',' ',filename)

            desc_ori = str.strip(matches.group(8))
            desc_ori = re.sub('www.legendasdivx.com','',desc_ori)
            
            _filenameon = "true"
            if _descon == "false":
                desc = re.findall(release_pattern, desc_ori, re.IGNORECASE | re.VERBOSE | re.DOTALL | re.UNICODE | re.MULTILINE)
                desc = " / ".join(desc)
                if desc != "": _filenameon = "false"
                if desc == "":
                    desc = re.findall(release_pattern1, desc_ori, re.IGNORECASE | re.VERBOSE | re.DOTALL | re.UNICODE | re.MULTILINE)
                    desc = " / ".join(desc)
                    if desc != "": _filenameon = "false"
                    if desc == "": desc = desc_ori; _filenameon = "true"
                    else: desc = desc; _filenameon = "false"
            else: desc = desc_ori; _filenameon = "true"
            
            desc = re.sub('<br />',' ',desc)
            desc = re.sub('<br>',' ',desc)
            desc = re.sub('\n',' ',desc)
            desc = re.sub(':.','',desc)
            desc = re.sub(r'<[^<]+?>|[~]','', desc)

            global filesearch
            filesearch = os.path.abspath(file_original_path)
            filesearch = os.path.split(filesearch)
            dirsearch = filesearch[0].split(os.sep)
            dirsearch_check = str.split(dirsearch[-1], '.')

            _parentfolder = _addon.getSetting( 'PARENT' )
            if _parentfolder == '0':
                if re.search(release_pattern, dirsearch[-1], re.IGNORECASE): _parentfolder = '1'
                else: _parentfolder = '2'
            if _parentfolder == '1':
                if re.search(dirsearch[-1], desc, re.IGNORECASE): sync = True
                else: sync = False
            if _parentfolder == '2':
                if (searchstring_notclean != ""):
                    sync = False
                    if str.lower(searchstring_notclean) in str.lower(desc): sync = True
                else:
                    if (str.lower(dirsearch_check[-1]) == "rar") or (str.lower(dirsearch_check[-1]) == "cd1") or (str.lower(dirsearch_check[-1]) == "cd2"):
                        sync = False
                        if len(dirsearch) > 1 and dirsearch[1] != '':
                            if re.search(filesearch[1][:len(filesearch[1])-4], desc, re.IGNORECASE) or re.search(dirsearch[-2], desc, re.IGNORECASE): sync = True
                        else:
                            if re.search(filesearch[1][:len(filesearch[1])-4], desc, re.IGNORECASE): sync = True
                    else:
                        sync = False
                        if len(dirsearch) > 1 and dirsearch[1] != '':
                            if re.search(filesearch[1][:len(filesearch[1])-4], desc) or re.search(dirsearch[-1], desc, re.IGNORECASE): sync = True
                        else:
                            if re.search(filesearch[1][:len(filesearch[1])-4], desc, re.IGNORECASE): sync = True
                            
            if _filenameon == "false": filename = "From: " + uploader + " - "  + desc + "  " + "hits: " + hits
            else: filename = "From: " + uploader + " - "  + filename + " " + "(" + movieyear + ")" + "  " + "hits: " + hits + " - " + desc
            
            subtitles_list.append({'rating': str(downloads), 'filename': filename, 'uploader': uploader, 'desc': desc, 'sync': sync, 'hits' : hits, 'id': id, 'language_short': languageshort, 'language_name': languagelong})
    
    for n in range(0,len(subtitles_list)):
        for i in range(1, len(subtitles_list)):
            temp = subtitles_list[i]
            if subtitles_list[i]["sync"] > subtitles_list[i-1]["sync"]:
                subtitles_list[i] = subtitles_list[i-1]
                subtitles_list[i-1] = temp
                
    return subtitles_list

def append_subtitle(item):
    listitem = xbmcgui.ListItem(label=item['language_name'], label2=item['filename'])
    listitem.setArt({ "icon": str(int(round(float(item["rating"])))), "thumb" : item["language_short"] })
    listitem.setProperty("sync", 'true' if item["sync"] else 'false')
    listitem.setProperty("hearing_imp", 'true' if item.get("hearing_imp", False) else 'false')

    args = dict(item)
    args['scriptid'] = _scriptid
    url = INTERNAL_LINK_URL % args
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=False)

class Main:
    def Search(item):
        username = _addon.getSetting( 'LDuser' )
        password = _addon.getSetting( 'LDpass' )
        if not username or not password:
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            if username == '' and password != '': _dialog.notification(_scriptname, _language(32016).encode('utf8'), xbmcgui.NOTIFICATION_ERROR)
            if username != '' and password == '': _dialog.notification(_scriptname, _language(32017).encode('utf8'), xbmcgui.NOTIFICATION_ERROR)
            if username == '' and password == '': _dialog.notification(_scriptname, _language(32018).encode('utf8'), xbmcgui.NOTIFICATION_ERROR)
            
        file_original_path = item['file_original_path']
        _parentfolder = _addon.getSetting( 'PARENT' )
        if _parentfolder == '0':
            filename_path = os.path.abspath(file_original_path)
            dirsearch = filename_path.split(os.sep)
            if re.search(release_pattern, dirsearch[-2], re.IGNORECASE): _parentfolder = '1'
            else: _parentfolder = '2'
        if _parentfolder == '1':
            filename_path = os.path.abspath(file_original_path)
            dirsearch = filename_path.split(os.sep)
            filename = dirsearch[-2]
        if _parentfolder == '2':   
            filename = os.path.splitext(os.path.basename(file_original_path))[0]
     
        c_title, c_year = get_clean_title(filename)
        filename = f"{c_title} {c_year}".strip()
        
        searchstring_notclean = os.path.splitext(os.path.basename(file_original_path))[0]
        searchstring = ""
        global israr
        israr = os.path.abspath(file_original_path)
        israr = os.path.split(israr)
        israr = israr[0].split(os.sep)
        israr = str.split(israr[-1], '.')
        israr = str.lower(israr[-1])

        title, _ = get_clean_title(item['title']) if item['title'] else ("", "")
        year = item['year']
        
        tvshow = item['tvshow']
        if tvshow:
            tvshow = tvshow.split('(')[0].strip()
        season = item['season']
        episode = item['episode']
        
        subtitles_list = []
        
        if item['mansearch']:
            searchstring = item['mansearchstr']
        else:
            # CORREÇÃO CRUCIAL: Se tiver episódio, usar estritamente o nome da série (tvshow) + SXXEXX
            if episode != '' and episode is not None and str(episode).isdigit():
                show_name = tvshow if tvshow else title
                if not show_name:
                    show_name, _ = get_clean_title(filename)
                searchstring = "%s S%02dE%02d" % (show_name, int(season), int(episode))
            elif title != '' and (episode == '' or episode is None or not str(episode).isdigit()):
                searchstring = "%s %s" % (title, year)
            else:
                if 'rar' in israr and searchstring is not None:
                    if 'cd1' in str.lower(title) or 'cd2' in str.lower(title) or 'cd3' in str.lower(title):
                        dirsearch = os.path.abspath(file_original_path)
                        dirsearch = os.path.split(dirsearch)
                        dirsearch = dirsearch[0].split(os.sep)
                        if len(dirsearch) > 1:
                            searchstring_notclean = dirsearch[-3]
                            c_tit, _ = get_clean_title(dirsearch[-3])
                            searchstring = c_tit
                        else: searchstring = title
                    else:
                        searchstring = filename
                elif 'cd1' in str.lower(title) or 'cd2' in str.lower(title) or 'cd3' in str.lower(title):
                    dirsearch = os.path.abspath(file_original_path)
                    dirsearch = os.path.split(dirsearch)
                    dirsearch = dirsearch[0].split(os.sep)
                    if len(dirsearch) > 1:
                        searchstring_notclean = dirsearch[-2]
                        c_tit, _ = get_clean_title(dirsearch[-2])
                        searchstring = c_tit
                    else:
                        title = os.path.split(file_original_path)
                        searchstring = title[-1]
                else:
                    if _search == '0':
                        if re.search("(.+?s[0-9][0-9]e[0-9][0-9])", filename, re.IGNORECASE):
                            match = re.search("(.+?s[0-9][0-9]e[0-9][0-9])", filename, re.IGNORECASE)
                            searchstring = match.group(0)
                        else:
                            searchstring = filename
                    else:
                        if re.search("(.+?s[0-9][0-9]e[0-9][0-9])", title, re.IGNORECASE):
                            match = re.search("(.+?s[0-9][0-9]e[0-9][0-9])", title, re.IGNORECASE)
                            searchstring = match.group(0)
                        else:
                            searchstring = title

        searchstring = searchstring.strip()

        PT_ON = _addon.getSetting( 'PT' )
        PTBR_ON = _addon.getSetting( 'PTBR' )
        ES_ON = _addon.getSetting( 'ES' )
        EN_ON = _addon.getSetting( 'EN' )
        
        if 'por' in item['languages'] and PT_ON == 'true':
            subtitles_list = getallsubs(searchstring, "pt", "Portuguese", file_original_path, searchstring_notclean)
            for sub in subtitles_list: append_subtitle(sub)
        if 'por' in item['languages'] and PTBR_ON == 'true':
            subtitles_list = getallsubs(searchstring, "pb", "Brazilian", file_original_path, searchstring_notclean)
            for sub in subtitles_list: append_subtitle(sub)
        if 'spa' in item['languages'] and ES_ON == 'true':
            subtitles_list = getallsubs(searchstring, "es", "Spanish", file_original_path, searchstring_notclean)
            for sub in subtitles_list: append_subtitle(sub)
        if 'eng' in item['languages'] and EN_ON == 'true':
            subtitles_list = getallsubs(searchstring, "en", "English", file_original_path, searchstring_notclean)
            for sub in subtitles_list: append_subtitle(sub)
        if 'eng' not in item['languages'] and 'spa' not in item['languages'] and 'por' not in item['languages']:
            _dialog.notification(_scriptname, 'Only Portuguese | Portuguese Brazilian | English | Spanish.', xbmcgui.NOTIFICATION_ERROR)
            
    def Download(id, filename):
        if os.path.isdir(_temp):shutil.rmtree(_temp)
        xbmcvfs.mkdirs(_temp)
        if not os.path.isdir(_temp):xbmcvfs.mkdir(_temp)
        unpacked = 'ldivx-' + str(uuid.uuid4()).replace("-","")[0:6]
        xbmcvfs.mkdirs(pjoin(_temp,unpacked,''))
        _newtemp = os.path.join(_temp, xbmcvfs.translatePath(unpacked).replace('\\','/'))

        subtitles_list = []
        my_opener = login()
        
        content = my_opener.open(main_url + 'modules.php?name=Downloads&d_op=getit&lid=' + id + '&username=' + _addon.getSetting( 'LDuser' ))
        content = content.read()
        
        if 'url=sair.php?referer=login' in content.decode('ISO-8859-1'):
            _dialog.notification(_scriptname, _language(32019).encode('utf8'), xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
            
        if content.decode('ISO-8859-1') is not None:
            header = content[:4].decode('ISO-8859-1')
            if header == 'Rar!':
                tmp_file = str(uuid.uuid4())+".rar"
                local_tmp_file = pjoin(_temp, tmp_file)
                packed = True
            elif header == 'PK  ':
                local_tmp_file = pjoin(_temp, str(uuid.uuid4())+".zip")
                packed = True
            else:
                local_tmp_file = pjoin(_temp, "ldivx.srt")
                subs_file = local_tmp_file
                packed = False
                
            try:
                with open(local_tmp_file, "wb") as local_file_handle:
                    local_file_handle.write(content)
                local_file_handle.close()
                xbmc.sleep(500)
            except:
                log("Failed to save subtitles to '%s'" % (local_tmp_file,))
                
            if packed:
                try:
                    compressed_file = 'rar://' + urllib.parse.quote_plus(local_tmp_file) + '/'
                    xbmc_extract(compressed_file,_newtemp)
                except:
                    xbmc.executebuiltin("XBMC.Extract(%s, %s)" % (compressed_file, _newtemp), True)
                
                searchsubs = recursive_glob(_newtemp, SUB_EXTS)
                searchsubscount = len(searchsubs)
                if searchsubscount == 0:
                    dialog = xbmcgui.Dialog()
                    subs_file = dialog.browse(1, _language(32024).encode('utf8'), 'files', '', False, True, _temp + '/')
                    subtitles_list.append(subs_file)
                else:
                    os.remove(local_tmp_file)
                    for file in searchsubs:
                        if searchsubscount == 1:
                            try:
                                subs_file = pjoin(_newtemp, file)
                            except:
                                pass
                            subtitles_list.append(subs_file)
                            break
                        else:
                            dialog = xbmcgui.Dialog()
                            subs_file = dialog.browse(1, _language(32024).encode('utf8'), 'files', '', False, True, _temp + '/')
                            subtitles_list.append(subs_file)
                            break
            else: subtitles_list.append(subs_file)
        return subtitles_list

    def get_params():
        param = []
        paramstring = sys.argv[2]
        if len(paramstring) >= 2:
            params = paramstring
            cleanedparams = params.replace('?', '')
            if params.endswith('/'): params = params[:-2] 
            pairsofparams = cleanedparams.split('&')
            param = {}
            for pair in pairsofparams:
                splitparams = {}
                splitparams = pair.split('=')
                if len(splitparams) == 2: param[splitparams[0]] = splitparams[1]
        return param

    params = get_params()

    if params['action'] == 'search' or params['action'] == 'manualsearch':
        item = {}
        item['temp']               = False
        item['rar']                = False
        item['year']               = xbmc.getInfoLabel("VideoPlayer.Year")
        item['season']             = str(xbmc.getInfoLabel("VideoPlayer.Season"))
        item['episode']            = str(xbmc.getInfoLabel("VideoPlayer.Episode"))
        item['tvshow']             = str(xbmcvfs.translatePath(xbmc.getInfoLabel("VideoPlayer.TVshowtitle"))) if xbmc.getInfoLabel("VideoPlayer.TVshowtitle") else str(xbmc.getInfoLabel("VideoPlayer.TVshowtitle"))
        item['tvshow']             = str(xbmc.getInfoLabel("VideoPlayer.TVshowtitle"))
        item['title']              = str(xbmc.getInfoLabel("VideoPlayer.OriginalTitle"))
        item['file_original_path'] = urllib.parse.unquote(xbmc.Player().getPlayingFile())
        item['mansearch'] = False
        item['languages'] = []

        if 'searchstring' in params:
            item['mansearch'] = True
            item['mansearchstr'] = urllib.parse.unquote(params['searchstring'])

        for lang in urllib.parse.unquote(params['languages']).split(','):
            item['languages'].append(xbmc.convertLanguage(lang, xbmc.ISO_639_2))

        if "s" in item['episode'].lower():
            item['season'] = "0"
            item['episode'] = item['episode'][-1:]

        if "http" in item['file_original_path']: item['temp'] = True
        elif "rar://" in item['file_original_path']:
            item['rar'] = True
            item['file_original_path'] = os.path.dirname(item['file_original_path'][6:])
        elif "stack://" in item['file_original_path']:
            stackPath = item['file_original_path'].split(" , ")
            item['file_original_path'] = stackPath[0][8:]

        Search(item)

    elif params['action'] == 'download':
        subs = Download(params["id"], params["filename"])
        for sub in subs:
            listitem = xbmcgui.ListItem(label=sub)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=sub, listitem=listitem, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))